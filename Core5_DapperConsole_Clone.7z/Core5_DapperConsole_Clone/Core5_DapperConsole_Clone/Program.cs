﻿using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using Dapper;
using System.Linq;

namespace Core5_DapperConsole_Clone
{
    internal class Program
    {
        static string connection = @"data source=(localdb)\mssqllocaldb;initial catalog=Northwind;integrated security=True;MultipleActiveResultSets=True;";

        static string connString = "";

        static void Main(string[] args)
        {
            //取得應用程式目錄
            var path = Directory.GetCurrentDirectory();

            //修正目錄
            string pathfix = path.Substring(0, path.IndexOf("bin"));

            //載入appsettings.json
            IConfiguration config = new ConfigurationBuilder()
               .SetBasePath(pathfix)
               .AddJsonFile("appsettings.json", optional: true)
               .Build();


            //IConfiguration config = builder.Build();

            if (string.IsNullOrEmpty(connString))
            {
                connString = config["ConnectionStrings:NorthwindContext"];
                connString = config.GetConnectionString("NorthwindContext");
            }

            //int i = 0;

            //QueryStringTyped();
            //QueryPraameterList();

            Employee emp = new Employee
            {
                FirstName = "大衛",
                LastName = "王",
                Title = "CEO",
                Country = "美國",
                EmployeeID = 10
            };

            int row = ExecuteInsert(emp);

            Console.WriteLine($"影響{row}筆資料!");

            Console.ReadKey();
        }

        static void QueryStringTyped()
        {
            List<Employee> employees = null;
            using (SqlConnection conn = new SqlConnection(@"data source=(localdb)\mssqllocaldb;initial catalog=Northwind;integrated security=True;MultipleActiveResultSets=True;"))
            {
                string sql = "select * from Employees";
                employees = conn.Query<Employee>(sql).ToList();
            }

            foreach (var emp in employees)
            {
                Console.WriteLine($"{emp.EmployeeID}, {emp.FirstName}, {emp.Title}, {emp.City}, {emp.Country}");
            }
        }

        static void QueryDynamicTyped()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string sql = "select * from Employees";
                var employees = conn.Query<Employee>(sql).ToList();

                foreach (var emp in employees)
                {
                    Console.WriteLine($"{emp.EmployeeID}, {emp.FirstName}, {emp.Title}, {emp.City}, {emp.Country}");
                }
            }           
        }

        static void QueryPraameters()
        {
            List<Employee> employees = null;
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string sql = "select * from Employees where Country=@country AND TitleOfCourtesy=@titleOfCourtesy";
                employees = conn.Query<Employee>(sql, new {country="USA", titleOfCourtesy="Ms." }).ToList();
            }

            foreach (var emp in employees)
            {
                Console.WriteLine($"{emp.EmployeeID}, {emp.FirstName}, {emp.Title}, {emp.City}, {emp.Country}");
            }
        }

        static void QueryPraameterList()
        {
            List<Employee> employees = null;
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string sql = "select * from Employees where EmployeeID in @IDs";
                employees = conn.Query<Employee>(sql, new { IDs = new int[] { 1, 3, 5 } } ).ToList();
            }

            foreach (var emp in employees)
            {
                Console.WriteLine($"{emp.EmployeeID}, {emp.FirstName}, {emp.Title}, {emp.City}, {emp.Country}");
            }
        }

        static void QueryPraameterSP()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                var emp = conn.Query<Employee>("FindEmployeeByName", 
                    new { LastName="King", FirstName = "Robert" }, 
                    commandType: CommandType.StoredProcedure).SingleOrDefault();

                Console.WriteLine($"{emp.EmployeeID}, {emp.FirstName}, {emp.Title}, {emp.City}, {emp.Country}");
            }
        }

        static int ExecuteInsert(Employee emp)
        {
            int affectedRows = 0;

            using (SqlConnection conn = new SqlConnection(connString))
            {
                string sql = "INSERT INTO Employees(FirstName, LastName, Title, Country) VALUES ( @FirstName, @LastName, @Title, @Country)";

                affectedRows = conn.Execute(sql, new
                {
                    emp.FirstName,
                    emp.LastName,
                    emp.Title,
                    emp.Country
                });
            }

            return affectedRows;
        }
    }
}
