﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Web;
using System.IO;
using System.Linq;
using Microsoft.AspNetCore.Hosting;
using System;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace CoreMvc5_FileUpload.Controllers
{
    public class FilesController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> UploadFile(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                ViewData["UploadMessage"] = "上傳檔案長度為0,失敗!";
                return View("UploadResult");
            }

            //取得作業系統的完整檔案路徑
            string pathFile = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "UploadFiles", file.FileName);

            try
            {
                using (var stream = new FileStream(pathFile, FileMode.Create))
                {
                    //以非同步方式將上傳檔案內容Copy複製寫入FileStream檔案資料流
                    await file.CopyToAsync(stream);
                }

                //相對路徑
                string virtualPath = Url.Content("UploadFiles/" + file.FileName);

                //完整URL路徑
                string url = $"{Request.Scheme}://{Request.Host.Value}/{virtualPath}";

                ViewData["UploadMessage"] = $"上傳成功,檔案路徑為: {url}";

            }
            catch (Exception ex)
            {
                ViewData["UploadMessage"] = "上傳失敗:" + ex.ToString();
            }

            return View("UploadResult");
        }
    }
}
