﻿namespace Core5_WebApiServices.Helpers
{
    public interface IUtility
    {
        int[] GetNumbers(int num);
    }
}
